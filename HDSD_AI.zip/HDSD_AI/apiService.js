// 1. Cấu hình đường dẫn gốc (Thay link Render của bạn vào đây)
const API_BASE_URL = "https://ai-recomment-chatbot.onrender.com";

/**
 * Hàm gọi Chatbot AI
 * @param {string} userId - ID của người dùng (để AI nhớ ngữ cảnh)
 * @param {string} message - Tin nhắn người dùng nhập
 */
export const sendMessageToAI = async (userId, message) => {
  try {
    const response = await fetch(`${API_BASE_URL}/chat`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      // Gửi đúng format JSON mà Backend yêu cầu
      body: JSON.stringify({
        user_id: userId, 
        message: message
      }),
    });

    if (!response.ok) throw new Error("Lỗi kết nối Server AI");

    const data = await response.json();
    return data.response; // Trả về câu trả lời của AI (Text)
  } catch (error) {
    console.error("Chatbot Error:", error);
    return "Xin lỗi, hệ thống AI đang bận.";
  }
};

/**
 * Hàm lấy Gợi ý sản phẩm (Recommend)
 * @param {string} userId - ID của người dùng
 */
export const getRecommendations = async (userId) => {
  try {
    const response = await fetch(`${API_BASE_URL}/recommend/${userId}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) throw new Error("Lỗi lấy gợi ý");

    const data = await response.json();
    return data; // Trả về mảng danh sách sản phẩm gợi ý
  } catch (error) {
    console.error("Recommendation Error:", error);
    return []; // Trả về mảng rỗng nếu lỗi
  }
};